<!-- 固定ページ：お問い合わせページを実装する場合に使用 -->
<!-- 管理画面より、slug名「contact」で固定ページを投稿 -->
<!-- 実装の参考：https://wp-master.club/view-contact-form7 -->